package kopo.poly.service.impl;

import kopo.poly.service.IQuizService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service("QuizService")
public class QuizService implements IQuizService {

}
