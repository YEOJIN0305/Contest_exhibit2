package kopo.poly.util;

public class PrivateUtil {
    public static String mainEmailID = "";
    public static String mainEmailPW = "";
}